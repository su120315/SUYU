async function safeCopyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) { /* fallthrough */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    return false;
  }
}

document.addEventListener('DOMContentLoaded', function() {
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }

  const modal = document.getElementById('toolModal');
  const modalTitle = document.getElementById('toolModalTitle');
  const modalBody = document.getElementById('toolModalBody');
  const modalClose = document.getElementById('toolModalClose');
  const modalOverlay = document.getElementById('toolModalOverlay');

  const toolCards = document.querySelectorAll('.tool-card');
  toolCards.forEach(card => {
    card.addEventListener('click', function() {
      const tool = this.dataset.tool;
      openTool(tool);
    });
  });

  function closeModal() {
    modal.classList.remove('active');
  }

  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', closeModal);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
  });

  // 键盘弹出时，聚焦输入框自动滚动到可视区域
  modalBody.addEventListener('focusin', function(e) {
    const tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') {
      setTimeout(function() {
        e.target.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }, 300);
    }
  });

  const tools = {
    calculator: { title: '计算器', render: renderCalculator },
    timer: { title: '倒计时 / 番茄钟', render: renderTimer },
    base64: { title: 'Base64 编解码', render: renderBase64 },
    json: { title: 'JSON 格式化', render: renderJson },
    color: { title: '颜色工具', render: renderColor },
    baseconv: { title: '进制转换', render: renderBaseConv },
    password: { title: '密码生成器', render: renderPassword },
    qrcode: { title: '二维码生成', render: renderQrcode },
    typing: { title: '打字速度测试', render: renderTyping },
    quote: { title: '随机名言', render: renderQuote },
    cad: { title: 'CAD工具箱', render: renderCad }
  };

  function openTool(toolName) {
    const tool = tools[toolName];
    if (!tool) return;
    modalTitle.textContent = tool.title;
    modalBody.innerHTML = '';
    tool.render(modalBody);
    if (toolName === 'cad') {
      modal.querySelector('.tool-modal-content').classList.add('cad-mode');
    } else {
      modal.querySelector('.tool-modal-content').classList.remove('cad-mode');
    }
    modal.classList.add('active');
    if (typeof lucide !== 'undefined') {
      lucide.createIcons();
    }
    setTimeout(function() { modalBody.scrollTop = 0; }, 50);
  }

  function renderCalculator(container) {
    container.innerHTML = `
      <div class="calc-display">
        <div class="calc-expression" id="calcExpr"></div>
        <div class="calc-result" id="calcResult">0</div>
      </div>
      <div class="calc-keys">
        <button class="calc-btn clear" data-action="clear">C</button>
        <button class="calc-btn clear" data-action="back">←</button>
        <button class="calc-btn op" data-val="%">%</button>
        <button class="calc-btn op" data-val="/">÷</button>
        <button class="calc-btn" data-val="7">7</button>
        <button class="calc-btn" data-val="8">8</button>
        <button class="calc-btn" data-val="9">9</button>
        <button class="calc-btn op" data-val="*">×</button>
        <button class="calc-btn" data-val="4">4</button>
        <button class="calc-btn" data-val="5">5</button>
        <button class="calc-btn" data-val="6">6</button>
        <button class="calc-btn op" data-val="-">−</button>
        <button class="calc-btn" data-val="1">1</button>
        <button class="calc-btn" data-val="2">2</button>
        <button class="calc-btn" data-val="3">3</button>
        <button class="calc-btn op" data-val="+">+</button>
        <button class="calc-btn" data-val="0">0</button>
        <button class="calc-btn" data-val=".">.</button>
        <button class="calc-btn equals" data-action="equals">=</button>
      </div>
    `;

    let expression = '';
    const exprEl = container.querySelector('#calcExpr');
    const resultEl = container.querySelector('#calcResult');

    function updateDisplay() {
      exprEl.textContent = expression.replace(/\*/g, '×').replace(/\//g, '÷').replace(/-/g, '−');
      try {
        if (expression) {
          const r = eval(expression.replace(/%/g, '/100'));
          if (!isNaN(r) && isFinite(r)) {
            resultEl.textContent = Math.round(r * 1e10) / 1e10;
          } else {
            resultEl.textContent = '错误';
          }
        } else {
          resultEl.textContent = '0';
        }
      } catch(e) {
        resultEl.textContent = '错误';
      }
    }

    container.querySelectorAll('.calc-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const action = this.dataset.action;
        const val = this.dataset.val;
        if (action === 'clear') { expression = ''; }
        else if (action === 'back') { expression = expression.slice(0, -1); }
        else if (action === 'equals') {
          try {
            const r = eval(expression.replace(/%/g, '/100'));
            if (!isNaN(r) && isFinite(r)) {
              expression = String(Math.round(r * 1e10) / 1e10);
            }
          } catch(e) {}
        }
        else if (val !== undefined) {
          const ops = ['+', '-', '*', '/', '%', '.'];
          const last = expression.slice(-1);
          if (ops.includes(val) && ops.includes(last)) {
            expression = expression.slice(0, -1) + val;
          } else {
            expression += val;
          }
        }
        updateDisplay();
      });
    });
  }

  function renderTimer(container) {
    container.innerHTML = `
      <div class="timer-topbar">
        <div class="timer-modes">
          <button class="timer-mode active" data-mode="countdown">倒计时</button>
          <button class="timer-mode" data-mode="clock">时钟</button>
          <button class="timer-mode" data-mode="stopwatch">秒表</button>
        </div>
        <button class="timer-fullscreen" id="timerFullscreen" title="全屏">
          <i data-lucide="maximize"></i>
        </button>
      </div>
      <div class="timer-display">
        <div class="timer-time" id="timerTime">25:00</div>
        <div class="timer-label" id="timerLabel">专注时间</div>
      </div>
      <div class="timer-presets" id="timerPresets">
        <button class="timer-preset active" data-min="25" data-label="专注时间">番茄 25min</button>
        <button class="timer-preset" data-min="5" data-label="短休息">休息 5min</button>
        <button class="timer-preset" data-min="15" data-label="长休息">长休 15min</button>
        <button class="timer-preset" data-min="60" data-label="学习时间">学习 60min</button>
        <button class="timer-preset timer-custom-btn" id="timerCustomBtn">
          <i data-lucide="settings-2" style="width:14px;height:14px;vertical-align:middle;margin-right:4px;"></i>自定义
        </button>
      </div>
      <div class="timer-custom-input" id="timerCustomInput">
        <div class="timer-custom-row">
          <div class="timer-custom-field">
            <input type="number" id="customMin" min="0" max="999" value="25">
            <span>分</span>
          </div>
          <div class="timer-custom-sep">:</div>
          <div class="timer-custom-field">
            <input type="number" id="customSec" min="0" max="59" value="0">
            <span>秒</span>
          </div>
          <button class="timer-custom-set" id="timerCustomSet">确定</button>
        </div>
      </div>
      <div class="timer-controls">
        <button class="timer-btn primary" id="timerStart">开始</button>
        <button class="timer-btn secondary" id="timerReset">重置</button>
      </div>
    `;

    let mode = 'countdown';
    let totalSeconds = 25 * 60;
    let remaining = totalSeconds;
    let timerId = null;
    let running = false;
    let stopwatchMs = 0;
    let stopwatchStart = 0;
    const timeEl = container.querySelector('#timerTime');
    const labelEl = container.querySelector('#timerLabel');
    const presetsEl = container.querySelector('#timerPresets');
    const startBtn = container.querySelector('#timerStart');
    const resetBtn = container.querySelector('#timerReset');

    function format(s) {
      const m = Math.floor(s / 60).toString().padStart(2, '0');
      const sec = (s % 60).toString().padStart(2, '0');
      return `${m}:${sec}`;
    }

    function formatClock() {
      const now = new Date();
      const h = now.getHours().toString().padStart(2, '0');
      const m = now.getMinutes().toString().padStart(2, '0');
      const s = now.getSeconds().toString().padStart(2, '0');
      return `${h}:${m}:${s}`;
    }

    function formatStopwatch(ms) {
      const totalSec = Math.floor(ms / 1000);
      const m = Math.floor(totalSec / 60).toString().padStart(2, '0');
      const s = (totalSec % 60).toString().padStart(2, '0');
      const cs = Math.floor((ms % 1000) / 10).toString().padStart(2, '0');
      return `${m}:${s}.${cs}`;
    }

    function updateDisplay() {
      if (mode === 'countdown') {
        timeEl.textContent = format(remaining);
      } else if (mode === 'clock') {
        timeEl.textContent = formatClock();
      } else if (mode === 'stopwatch') {
        timeEl.textContent = formatStopwatch(stopwatchMs);
      }
    }

    function stopTimer() {
      if (timerId) {
        clearInterval(timerId);
        timerId = null;
      }
      running = false;
      startBtn.textContent = mode === 'stopwatch' ? '开始' : '开始';
    }

    function switchMode(newMode) {
      mode = newMode;
      stopTimer();

      container.querySelectorAll('.timer-mode').forEach(b => b.classList.remove('active'));
      container.querySelector(`[data-mode="${newMode}"]`).classList.add('active');

      if (newMode === 'countdown') {
        presetsEl.style.display = 'flex';
        labelEl.textContent = '专注时间';
        remaining = totalSeconds;
        startBtn.textContent = '开始';
        resetBtn.style.display = '';
        startBtn.style.display = '';
        hideCustomInput();
      } else if (newMode === 'clock') {
        presetsEl.style.display = 'none';
        labelEl.textContent = new Date().toLocaleDateString('zh-CN', { weekday: 'long', month: 'long', day: 'numeric' });
        startBtn.style.display = 'none';
        resetBtn.style.display = 'none';
        timerId = setInterval(updateDisplay, 1000);
      } else if (newMode === 'stopwatch') {
        presetsEl.style.display = 'none';
        labelEl.textContent = '秒表计时';
        stopwatchMs = 0;
        startBtn.style.display = '';
        startBtn.textContent = '开始';
        resetBtn.style.display = '';
      }
      updateDisplay();
    }

    container.querySelectorAll('.timer-mode').forEach(btn => {
      btn.addEventListener('click', function() {
        switchMode(this.dataset.mode);
      });
    });

    container.querySelectorAll('.timer-preset:not(.timer-custom-btn)').forEach(btn => {
      btn.addEventListener('click', function() {
        container.querySelectorAll('.timer-preset').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        totalSeconds = parseInt(this.dataset.min) * 60;
        remaining = totalSeconds;
        labelEl.textContent = this.dataset.label;
        stopTimer();
        updateDisplay();
        hideCustomInput();
      });
    });

    const customBtn = container.querySelector('#timerCustomBtn');
    const customInputEl = container.querySelector('#timerCustomInput');
    const customMinInput = container.querySelector('#customMin');
    const customSecInput = container.querySelector('#customSec');
    const customSetBtn = container.querySelector('#timerCustomSet');

    function showCustomInput() {
      customInputEl.style.display = 'flex';
      customMinInput.value = Math.floor(totalSeconds / 60);
      customSecInput.value = totalSeconds % 60;
      setTimeout(() => customMinInput.focus(), 50);
    }

    function hideCustomInput() {
      customInputEl.style.display = 'none';
    }

    customBtn.addEventListener('click', function() {
      container.querySelectorAll('.timer-preset').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      if (customInputEl.style.display === 'flex') {
        hideCustomInput();
      } else {
        showCustomInput();
      }
    });

    function applyCustomTime() {
      let m = parseInt(customMinInput.value) || 0;
      let s = parseInt(customSecInput.value) || 0;
      if (m < 0) m = 0;
      if (s < 0) s = 0;
      if (s > 59) s = 59;
      if (m > 999) m = 999;
      totalSeconds = m * 60 + s;
      if (totalSeconds <= 0) totalSeconds = 1;
      remaining = totalSeconds;
      labelEl.textContent = `自定义 ${m}分${s}秒`;
      stopTimer();
      updateDisplay();
    }

    customSetBtn.addEventListener('click', applyCustomTime);

    customMinInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') applyCustomTime();
    });
    customSecInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') applyCustomTime();
    });

    startBtn.addEventListener('click', function() {
      if (mode === 'countdown') {
        if (running) {
          stopTimer();
        } else {
          if (remaining <= 0) remaining = totalSeconds;
          running = true;
          startBtn.textContent = '暂停';
          timerId = setInterval(() => {
            remaining--;
            updateDisplay();
            if (remaining <= 0) {
              stopTimer();
              try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.connect(g); g.connect(ctx.destination);
                o.frequency.value = 800;
                g.gain.setValueAtTime(0.3, ctx.currentTime);
                g.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
                o.start(); o.stop(ctx.currentTime + 0.5);
              } catch(e) {}
              alert('时间到啦！⏰');
            }
          }, 1000);
        }
      } else if (mode === 'stopwatch') {
        if (running) {
          stopTimer();
          stopwatchMs += Date.now() - stopwatchStart;
        } else {
          running = true;
          stopwatchStart = Date.now();
          startBtn.textContent = '暂停';
          timerId = setInterval(() => {
            const current = stopwatchMs + Date.now() - stopwatchStart;
            timeEl.textContent = formatStopwatch(current);
          }, 10);
        }
      }
    });

    resetBtn.addEventListener('click', function() {
      stopTimer();
      if (mode === 'countdown') {
        remaining = totalSeconds;
      } else if (mode === 'stopwatch') {
        stopwatchMs = 0;
      }
      updateDisplay();
    });

    const fsBtn = container.querySelector('#timerFullscreen');
    let isFullscreen = false;

    function enterFullscreen() {
      const modalContent = document.querySelector('.tool-modal-content');
      if (modalContent) {
        modalContent.classList.add('timer-fs');
      }
      isFullscreen = true;
      fsBtn.innerHTML = '<i data-lucide="minimize"></i>';
      if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    function exitFullscreen() {
      const modalContent = document.querySelector('.tool-modal-content');
      if (modalContent) {
        modalContent.classList.remove('timer-fs');
      }
      isFullscreen = false;
      fsBtn.innerHTML = '<i data-lucide="maximize"></i>';
      if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    fsBtn.addEventListener('click', function() {
      if (isFullscreen) {
        exitFullscreen();
      } else {
        enterFullscreen();
      }
    });

    updateDisplay();
  }

  function renderBase64(container) {
    container.innerHTML = `
      <div class="text-tool-label">原始文本</div>
      <textarea class="text-tool-area" id="b64Input" placeholder="输入要编码/解码的文字..."></textarea>
      <div class="text-tool-row">
        <button class="text-tool-btn primary" id="b64Encode">编码 → Base64</button>
        <button class="text-tool-btn" id="b64Decode">Base64 → 解码</button>
        <button class="text-tool-btn" id="b64Copy">复制结果</button>
      </div>
      <div class="text-tool-label">结果</div>
      <textarea class="text-tool-area" id="b64Output" placeholder="结果会显示在这里..." readonly></textarea>
      <div class="text-tool-status" id="b64Status"></div>
    `;

    const input = container.querySelector('#b64Input');
    const output = container.querySelector('#b64Output');
    const status = container.querySelector('#b64Status');

    function showStatus(msg, type) {
      status.textContent = msg;
      status.className = 'text-tool-status ' + type;
      setTimeout(() => { status.textContent = ''; status.className = 'text-tool-status'; }, 2000);
    }

    container.querySelector('#b64Encode').addEventListener('click', function() {
      try {
        output.value = btoa(unescape(encodeURIComponent(input.value)));
        showStatus('编码成功 ✅', 'success');
      } catch(e) {
        showStatus('编码失败 ❌', 'error');
      }
    });

    container.querySelector('#b64Decode').addEventListener('click', function() {
      try {
        output.value = decodeURIComponent(escape(atob(input.value.trim())));
        showStatus('解码成功 ✅', 'success');
      } catch(e) {
        showStatus('解码失败：输入不是有效的 Base64 ❌', 'error');
      }
    });

    container.querySelector('#b64Copy').addEventListener('click', async function() {
      if (!output.value) return;
      const ok = await safeCopyText(output.value);
      showStatus(ok ? '已复制到剪贴板 📋' : '复制失败 ❌', ok ? 'success' : 'error');
    });
  }

  function renderJson(container) {
    container.innerHTML = `
      <div class="text-tool-label">JSON 内容</div>
      <textarea class="text-tool-area" id="jsonInput" placeholder='{"name": "suyu", "age": 14}'></textarea>
      <div class="text-tool-row">
        <button class="text-tool-btn primary" id="jsonFormat">格式化</button>
        <button class="text-tool-btn" id="jsonMinify">压缩</button>
        <button class="text-tool-btn" id="jsonCopy">复制</button>
        <button class="text-tool-btn" id="jsonClear">清空</button>
      </div>
      <div class="text-tool-label">结果</div>
      <textarea class="text-tool-area" id="jsonOutput" placeholder="结果会显示在这里..." readonly></textarea>
      <div class="text-tool-status" id="jsonStatus"></div>
    `;

    const input = container.querySelector('#jsonInput');
    const output = container.querySelector('#jsonOutput');
    const status = container.querySelector('#jsonStatus');

    function showStatus(msg, type) {
      status.textContent = msg;
      status.className = 'text-tool-status ' + type;
      setTimeout(() => { status.textContent = ''; status.className = 'text-tool-status'; }, 2000);
    }

    container.querySelector('#jsonFormat').addEventListener('click', function() {
      try {
        const obj = JSON.parse(input.value);
        output.value = JSON.stringify(obj, null, 2);
        showStatus('格式化成功 ✅', 'success');
      } catch(e) {
        showStatus('JSON 格式错误：' + e.message + ' ❌', 'error');
      }
    });

    container.querySelector('#jsonMinify').addEventListener('click', function() {
      try {
        const obj = JSON.parse(input.value);
        output.value = JSON.stringify(obj);
        showStatus('压缩成功 ✅', 'success');
      } catch(e) {
        showStatus('JSON 格式错误：' + e.message + ' ❌', 'error');
      }
    });

    container.querySelector('#jsonCopy').addEventListener('click', async function() {
      if (!output.value) return;
      const ok = await safeCopyText(output.value);
      showStatus(ok ? '已复制到剪贴板 📋' : '复制失败 ❌', ok ? 'success' : 'error');
    });

    container.querySelector('#jsonClear').addEventListener('click', function() {
      input.value = '';
      output.value = '';
    });
  }

  function renderColor(container) {
    container.innerHTML = `
      <div class="color-picker-row">
        <div class="color-preview" id="colorPreview" style="background: #6366f1;"></div>
        <div class="color-input-group">
          <label>HEX</label>
          <input type="text" id="colorHex" value="#6366f1">
        </div>
      </div>
      <div class="color-values">
        <div class="color-value-item">
          <label>RGB</label>
          <span id="colorRgb">rgb(99, 102, 241)</span>
        </div>
        <div class="color-value-item">
          <label>HSL</label>
          <span id="colorHsl">hsl(239, 84%, 67%)</span>
        </div>
        <div class="color-value-item">
          <label>R</label>
          <span id="colorR">99</span>
        </div>
        <div class="color-value-item">
          <label>G</label>
          <span id="colorG">102</span>
        </div>
        <div class="color-value-item">
          <label>B</label>
          <span id="colorB">241</span>
        </div>
        <div class="color-value-item">
          <label>亮度</label>
          <span id="colorLum">67%</span>
        </div>
      </div>
    `;

    const preview = container.querySelector('#colorPreview');
    const hexInput = container.querySelector('#colorHex');

    function hexToRgb(hex) {
      hex = hex.replace('#', '');
      if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      return { r, g, b };
    }

    function rgbToHsl(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      let h, s, l = (max + min) / 2;
      if (max === min) { h = s = 0; }
      else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch(max) {
          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
          case g: h = (b - r) / d + 2; break;
          case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
      }
      return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
    }

    function updateColor(hex) {
      if (!/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex)) return;
      if (!hex.startsWith('#')) hex = '#' + hex;
      const { r, g, b } = hexToRgb(hex);
      const hsl = rgbToHsl(r, g, b);
      preview.style.background = hex;
      container.querySelector('#colorRgb').textContent = `rgb(${r}, ${g}, ${b})`;
      container.querySelector('#colorHsl').textContent = `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`;
      container.querySelector('#colorR').textContent = r;
      container.querySelector('#colorG').textContent = g;
      container.querySelector('#colorB').textContent = b;
      container.querySelector('#colorLum').textContent = hsl.l + '%';
    }

    hexInput.addEventListener('input', function() {
      updateColor(this.value);
    });
  }

  function renderBaseConv(container) {
    container.innerHTML = `
      <div class="baseconv-grid">
        <div class="baseconv-item">
          <label>十进制</label>
          <input type="text" id="bc10" value="255">
        </div>
        <div class="baseconv-item">
          <label>二进制</label>
          <input type="text" id="bc2">
        </div>
        <div class="baseconv-item">
          <label>八进制</label>
          <input type="text" id="bc8">
        </div>
        <div class="baseconv-item">
          <label>十六进制</label>
          <input type="text" id="bc16">
        </div>
      </div>
    `;

    const inputs = {
      2: container.querySelector('#bc2'),
      8: container.querySelector('#bc8'),
      10: container.querySelector('#bc10'),
      16: container.querySelector('#bc16')
    };

    function convert(fromBase, value) {
      value = value.trim();
      if (!value) {
        Object.values(inputs).forEach(i => { if (i !== inputs[fromBase]) i.value = ''; });
        return;
      }
      try {
        const dec = parseInt(value, fromBase);
        if (isNaN(dec)) throw new Error();
        for (const base in inputs) {
          if (parseInt(base) !== fromBase) {
            inputs[base].value = dec.toString(parseInt(base)).toUpperCase();
          }
        }
      } catch(e) {}
    }

    for (const base in inputs) {
      inputs[base].addEventListener('input', function() {
        convert(parseInt(base), this.value);
      });
    }

    convert(10, '255');
  }

  function renderPassword(container) {
    container.innerHTML = `
      <div class="password-output">
        <input type="text" id="pwOutput" readonly>
        <button class="password-copy" id="pwCopy">复制</button>
      </div>
      <div class="password-options">
        <div class="password-option">
          <label>密码长度</label>
          <input type="number" id="pwLen" value="16" min="4" max="64">
        </div>
        <div class="password-option">
          <label>大写字母 (A-Z)</label>
          <input type="checkbox" id="pwUpper" checked>
        </div>
        <div class="password-option">
          <label>小写字母 (a-z)</label>
          <input type="checkbox" id="pwLower" checked>
        </div>
        <div class="password-option">
          <label>数字 (0-9)</label>
          <input type="checkbox" id="pwNum" checked>
        </div>
        <div class="password-option">
          <label>特殊符号 (!@#$...)</label>
          <input type="checkbox" id="pwSym">
        </div>
      </div>
      <button class="password-generate" id="pwGen">生成密码</button>
    `;

    const output = container.querySelector('#pwOutput');

    function generate() {
      const len = parseInt(container.querySelector('#pwLen').value) || 16;
      const upper = container.querySelector('#pwUpper').checked;
      const lower = container.querySelector('#pwLower').checked;
      const num = container.querySelector('#pwNum').checked;
      const sym = container.querySelector('#pwSym').checked;

      let chars = '';
      if (upper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      if (lower) chars += 'abcdefghijklmnopqrstuvwxyz';
      if (num) chars += '0123456789';
      if (sym) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
      if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

      let pw = '';
      const arr = new Uint32Array(len);
      crypto.getRandomValues(arr);
      for (let i = 0; i < len; i++) {
        pw += chars[arr[i] % chars.length];
      }
      output.value = pw;
    }

    container.querySelector('#pwGen').addEventListener('click', generate);
    container.querySelector('#pwCopy').addEventListener('click', async function() {
      if (!output.value) return;
      const ok = await safeCopyText(output.value);
      this.textContent = ok ? '已复制' : '复制失败';
      setTimeout(() => this.textContent = '复制', 1500);
    });

    generate();
  }

  function renderQrcode(container) {
    container.innerHTML = `
      <div class="qrcode-input">
        <label>输入文字或链接</label>
        <textarea id="qrText" placeholder="https://su120315.github.io/SUYU/"></textarea>
      </div>
      <button class="qrcode-generate" id="qrGen">生成二维码</button>
      <div class="qrcode-output" id="qrOutput">
        <span style="color: var(--text-muted); font-size: 0.9rem;">点击上方按钮生成二维码</span>
      </div>
    `;

    const output = container.querySelector('#qrOutput');
    const text = container.querySelector('#qrText');

    container.querySelector('#qrGen').addEventListener('click', function() {
      const t = text.value.trim();
      if (!t) { alert('请输入内容'); return; }
      output.innerHTML = '';

      if (typeof QRCode !== 'undefined') {
        const qrDiv = document.createElement('div');
        output.appendChild(qrDiv);
        try {
          new QRCode(qrDiv, {
            text: t,
            width: 220,
            height: 220,
            colorDark: '#0f172a',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.H
          });
        } catch (err) {
          output.innerHTML = '<span style="color:#ef4444;">生成失败，请重试</span>';
        }
      } else {
        output.innerHTML = '<span style="color:#f59e0b;">QRCode 库加载中，请稍候再试...</span>';
      }
    });
  }

  // ==================== 打字速度测试 ====================
  function renderTyping(container) {
    // 经典中文段落（约130字）
    const passage = '君子曰：学不可以已。青，取之于蓝，而青于蓝；冰，水为之，而寒于水。木直中绳，輮以为轮，其曲中规。虽有槁暴，不复挺者，輮使之然也。故木受绳则直，金就砺则利，君子博学而日参省乎己，则知明而行无过矣。';

    container.innerHTML = `
      <div class="typing-passage" id="typingPassage">${passage}</div>
      <textarea class="typing-input" id="typingInput" placeholder="在此输入上面的文字..." disabled></textarea>
      <div class="typing-stats">
        <div class="typing-stat">
          <span class="typing-stat-label">已用时间</span>
          <span class="typing-stat-value" id="typingTime">0s</span>
        </div>
        <div class="typing-stat">
          <span class="typing-stat-label">速度</span>
          <span class="typing-stat-value" id="typingSpeed">0 字/分</span>
        </div>
        <div class="typing-stat">
          <span class="typing-stat-label">准确率</span>
          <span class="typing-stat-value" id="typingAcc">100%</span>
        </div>
      </div>
      <button class="typing-btn" id="typingStart">开始</button>
    `;

    const passageEl = container.querySelector('#typingPassage');
    const inputEl = container.querySelector('#typingInput');
    const timeEl = container.querySelector('#typingTime');
    const speedEl = container.querySelector('#typingSpeed');
    const accEl = container.querySelector('#typingAcc');
    const startBtn = container.querySelector('#typingStart');

    const original = passage.replace(/\s/g, '');
    let startTime = null;
    let timerId = null;
    let started = false;

    // 重置状态
    function reset() {
      started = false;
      if (timerId) { clearInterval(timerId); timerId = null; }
      startTime = null;
      inputEl.value = '';
      inputEl.disabled = true;
      timeEl.textContent = '0s';
      speedEl.textContent = '0 字/分';
      accEl.textContent = '100%';
      passageEl.querySelectorAll('.typing-correct, .typing-wrong').forEach(function(el) {
        el.classList.remove('typing-correct', 'typing-wrong');
      });
      startBtn.textContent = '开始';
    }

    // 高亮已输入字符：正确/错误标记
    function highlightInput() {
      const typed = inputEl.value.replace(/\s/g, '');
      const chars = passageEl.querySelectorAll('.typing-char');
      chars.forEach(function(el, i) {
        el.classList.remove('typing-correct', 'typing-wrong');
        if (i < typed.length) {
          el.classList.add(typed[i] === original[i] ? 'typing-correct' : 'typing-wrong');
        }
      });
    }

    // 更新统计面板
    function updateStats() {
      const typed = inputEl.value.replace(/\s/g, '');
      const elapsed = (Date.now() - startTime) / 1000;
      timeEl.textContent = Math.floor(elapsed) + 's';

      // 打字速度：已正确输入字数 / 分钟
      let correctCount = 0;
      for (let i = 0; i < typed.length; i++) {
        if (typed[i] === original[i]) correctCount++;
      }
      const speed = elapsed > 0 ? Math.round(correctCount / elapsed * 60) : 0;
      speedEl.textContent = speed + ' 字/分';

      // 准确率
      const acc = typed.length > 0 ? Math.round(correctCount / typed.length * 100) : 100;
      accEl.textContent = acc + '%';
    }

    // 将原文拆分为单个字符 span
    function initPassageDisplay() {
      passageEl.innerHTML = '';
      for (const ch of original) {
        const span = document.createElement('span');
        span.className = 'typing-char';
        span.textContent = ch;
        passageEl.appendChild(span);
      }
    }
    initPassageDisplay();

    // 开始/重置按钮
    startBtn.addEventListener('click', function() {
      if (started) {
        // 已完成或进行中点击重置
        reset();
        startBtn.textContent = '开始';
        return;
      }

      // 开始打字
      startBtn.textContent = '重置';
      inputEl.disabled = false;
      inputEl.focus();
      started = true;
      startTime = Date.now();

      // 每秒更新统计
      timerId = setInterval(function() {
        if (startTime) updateStats();
      }, 200);
    });

    // 输入事件：高亮 + 判断完成
    inputEl.addEventListener('input', function() {
      if (!started) return;
      highlightInput();
      if (startTime) updateStats();

      // 判断是否全部输入完成
      const typed = inputEl.value.replace(/\s/g, '');
      if (typed.length >= original.length) {
        if (timerId) { clearInterval(timerId); timerId = null; }
        inputEl.disabled = true;
        startBtn.textContent = '完成 ✓';
        // 最终统计
        updateStats();
      }
    });
  }

  // ==================== 随机名言 ====================
  function renderQuote(container) {
    // 中文名言数组（至少20条，带出处）
    const quotes = [
      { text: '学而不思则罔，思而不学则殆。', source: '《论语·为政》' },
      { text: '温故而知新，可以为师矣。', source: '《论语·为政》' },
      { text: '三人行，必有我师焉。择其善者而从之，其不善者而改之。', source: '《论语·述而》' },
      { text: '知之为知之，不知为不知，是知也。', source: '《论语·为政》' },
      { text: '己所不欲，勿施于人。', source: '《论语·颜渊》' },
      { text: '千里之行，始于足下。', source: '《老子》' },
      { text: '天行健，君子以自强不息。', source: '《周易》' },
      { text: '地势坤，君子以厚德载物。', source: '《周易》' },
      { text: '路漫漫其修远兮，吾将上下而求索。', source: '屈原《离骚》' },
      { text: '生于忧患，死于安乐。', source: '《孟子·告子下》' },
      { text: '老吾老以及人之老，幼吾幼以及人之幼。', source: '《孟子·梁惠王上》' },
      { text: '纸上得来终觉浅，绝知此事要躬行。', source: '陆游《冬夜读书示子聿》' },
      { text: '书山有路勤为径，学海无涯苦作舟。', source: '韩愈《古今贤文》' },
      { text: '业精于勤，荒于嬉；行成于思，毁于随。', source: '韩愈《进学解》' },
      { text: '山重水复疑无路，柳暗花明又一村。', source: '陆游《游山西村》' },
      { text: '长风破浪会有时，直挂云帆济沧海。', source: '李白《行路难》' },
      { text: '人生自古谁无死？留取丹心照汗青。', source: '文天祥《过零丁洋》' },
      { text: '先天下之忧而忧，后天下之乐而乐。', source: '范仲淹《岳阳楼记》' },
      { text: '但愿人长久，千里共婵娟。', source: '苏轼《水调歌头》' },
      { text: '问渠那得清如许？为有源头活水来。', source: '朱熹《观书有感》' },
      { text: '锲而不舍，金石可镂；锲而舍之，朽木不折。', source: '《荀子·劝学》' },
      { text: '不积跬步，无以至千里；不积小流，无以成江海。', source: '《荀子·劝学》' },
      { text: '宝剑锋从磨砺出，梅花香自苦寒来。', source: '《警世贤文》' }
    ];

    container.innerHTML = `
      <div class="quote-display" id="quoteDisplay">
        <div class="quote-text" id="quoteText">点击下方按钮，获取一句名言</div>
        <div class="quote-source" id="quoteSource"></div>
      </div>
      <button class="quote-btn" id="quoteBtn">随机显示</button>
    `;

    const textEl = container.querySelector('#quoteText');
    const sourceEl = container.querySelector('#quoteSource');
    const btnEl = container.querySelector('#quoteBtn');

    // 随机获取一条名言
    function showRandomQuote() {
      const idx = Math.floor(Math.random() * quotes.length);
      const quote = quotes[idx];

      // 淡入动画：移除再添加类以重新触发
      textEl.classList.remove('quote-fade-in');
      sourceEl.classList.remove('quote-fade-in');

      // 使用 setTimeout 触发 reflow 使动画重新生效
      void textEl.offsetWidth;

      textEl.textContent = '「' + quote.text + '」';
      sourceEl.textContent = '—— ' + quote.source;

      textEl.classList.add('quote-fade-in');
      sourceEl.classList.add('quote-fade-in');
    }

    btnEl.addEventListener('click', showRandomQuote);
  }

  function renderCad(container) {
    function v1(code, mode) {
      try {
        if (mode === "adb") {
          const i1 = parseInt(code.substring(0, 2));
          const i2 = parseInt(code.substring(2, 4));
          const i3 = parseInt(code.substring(4, 6));
          const i4 = parseInt(code.substring(6, 8));
          const i5 = parseInt(code.substring(8));
          const i6 = i5 ^ (i3 + i4);
          const i7 = i4 ^ i6;
          const i8 = i3 ^ i6;
          const i9 = i1 ^ i6;
          const i10 = i2 ^ i6;
          let i = "";
          for (const x of [i9, i10, i8, i7, i6]) {
            i += x.toString().length === 1 ? "0" + x.toString() : x.toString();
          }
          const i1_2 = parseInt(i.substring(0, 2));
          const i2_2 = parseInt(i.substring(2, 4));
          const i3_2 = parseInt(i.substring(4, 6));
          const i4_2 = parseInt(i.substring(6, 8));
          const i5_2 = parseInt(i.substring(8));
          const i6_2 = i4_2 ^ i3_2;
          const i7_2 = i5_2 ^ i3_2;
          const i8_2 = i3_2 ^ (i6_2 + i7_2);
          const i9_2 = i1_2 ^ i7_2;
          const i10_2 = i2_2 ^ i7_2;
          let i2_result = "";
          for (const x of [i9_2, i10_2, i6_2, i7_2, i8_2]) {
            i2_result += x.toString().length === 1 ? "0" + x.toString() : x.toString();
          }
          return i2_result;
        } else if (mode === "zj") {
          const i1 = parseInt(code.substring(0, 2));
          const i2 = parseInt(code.substring(2, 4));
          const i3 = parseInt(code.substring(4));
          const i5 = i3 ^ (i1 + i2);
          const i6 = i1 ^ i5;
          const i4 = i2 ^ i5;
          let i = "";
          for (const x of [i6, i4, i5]) {
            i += x.toString().length === 1 ? "0" + x.toString() : x.toString();
          }
          const i1_2 = parseInt(i.substring(0, 2));
          const i2_2 = parseInt(i.substring(2, 4));
          const i3_2 = parseInt(i.substring(4));
          const i5_2 = i2_2 ^ i1_2;
          const i6_2 = i3_2 ^ i1_2;
          const i4_2 = i1_2 ^ (i5_2 + i6_2);
          let i2_result = "";
          for (const x of [i5_2, i6_2, i4_2]) {
            i2_result += x.toString().length === 1 ? "0" + x.toString() : x.toString();
          }
          return i2_result;
        }
      } catch(e) { return ""; }
      return "";
    }

    function v2(code, mode) {
      try {
        const num = mode === "adb" ? 2 : 1;
        if (/^\d+$/.test(code)) {
          const key = parseInt(code[7]) ^ num;
          const v7 = (parseInt(code[key]) - key + 10) % 10;
          let result1 = "";
          for (let i = 0; i < 7; i++) {
            const curKey = v7;
            result1 += i === key ? v7.toString() : ((parseInt(code[i]) + 10 - curKey) % 10).toString();
          }
          const keyId = Math.floor(Math.random() * 7);
          const keyValue = parseInt(result1[keyId]);
          let result = "";
          for (let i = 0; i < 7; i++) {
            const curKey = i === keyId ? keyId : keyValue;
            result += ((parseInt(result1[i]) + curKey) % 10).toString();
          }
          result += (num ^ keyId).toString();
          return result;
        }
      } catch(e) { return ""; }
      return "";
    }

    function getCode(code, mode) {
      if (code.length === 8) {
        let result = null;
        let tries = 0;
        while (tries++ < 100) {
          result = v2(code, mode);
          if (result != null && result !== code) break;
        }
        return result || code;
      } else {
        return v1(code, mode);
      }
    }

    container.innerHTML = `
      <div class="cad-calculator">
        <div class="cad-header">
          <h2>小天才校验码计算器</h2>
          <p>输入校验码后，点击计算即可获取结果</p>
          <p class="cad-source">
            <i data-lucide="github"></i>
            源码来源：<a href="https://github.com/OnesoftQwQ/XTCADBCode-Web" target="_blank" rel="noopener">OnesoftQwQ/XTCADBCode-Web</a>
          </p>
        </div>

        <div class="cad-input-group">
          <label for="cadCodeInput" class="cad-label">输入校验码：</label>
          <input type="text" id="cadCodeInput" class="cad-input" placeholder="请输入校验码..." maxlength="20">
        </div>

        <div class="cad-mode-selector">
          <button type="button" class="cad-mode-btn active" data-mode="adb">ADB</button>
          <button type="button" class="cad-mode-btn" data-mode="zj">自检</button>
        </div>

        <button type="button" class="cad-calc-btn" id="cadCalcBtn">计算</button>

        <div id="cadResult" class="cad-result hidden">
          <div class="cad-result-title" id="cadResultTitle"></div>
          <div class="cad-result-value" id="cadResultValue"></div>
        </div>

        <div class="cad-tips">
          <h3><i data-lucide="alert-circle"></i> 提示</h3>
          <p>如果你的手表在输入校验码后提示"验证中"，代表你的手表已经升级到V3版本校验码，V3校验码当前除了小天才官方外无法计算。</p>
        </div>
      </div>
    `;

    if (typeof lucide !== 'undefined') {
      try { lucide.createIcons(); } catch(e) {}
    }

    let currentMode = 'adb';
    const codeInput = container.querySelector('#cadCodeInput');
    const calcBtn = container.querySelector('#cadCalcBtn');
    const adbBtn = container.querySelector('.cad-mode-btn[data-mode="adb"]');
    const zjBtn = container.querySelector('.cad-mode-btn[data-mode="zj"]');
    const resultEl = container.querySelector('#cadResult');
    const resultTitle = container.querySelector('#cadResultTitle');
    const resultValue = container.querySelector('#cadResultValue');

    function setMode(mode) {
      currentMode = mode;
      if (mode === 'adb') {
        adbBtn.classList.add('active');
        zjBtn.classList.remove('active');
      } else {
        adbBtn.classList.remove('active');
        zjBtn.classList.add('active');
      }
    }

    function showError(msg) {
      resultEl.className = 'cad-result cad-error';
      resultTitle.textContent = '错误';
      resultValue.textContent = msg;
      resultEl.classList.remove('hidden');
    }

    function showSuccess(result) {
      resultEl.className = 'cad-result cad-success';
      resultTitle.textContent = '计算结果';
      resultValue.textContent = result;
      resultEl.classList.remove('hidden');
    }

    function calculate() {
      const code = codeInput.value.trim();
      if (!code) {
        showError('请输入校验码');
        return;
      }
      if (!/^\d+$/.test(code)) {
        showError('校验码必须为数字');
        return;
      }
      const result = getCode(code, currentMode);
      if (result === '') {
        showError('计算失败，请检查输入格式');
      } else {
        showSuccess(result);
      }
    }

    calcBtn.addEventListener('click', calculate);
    adbBtn.addEventListener('click', () => setMode('adb'));
    zjBtn.addEventListener('click', () => setMode('zj'));
    codeInput.addEventListener('keypress', e => {
      if (e.key === 'Enter') calculate();
    });
  }
});
